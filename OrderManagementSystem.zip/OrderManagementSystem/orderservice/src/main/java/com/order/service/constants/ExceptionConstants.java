package com.order.service.constants;


public class ExceptionConstants {

	//Error Modules
	public static final String GENERAL_MODULE = "GENERAL";
	
	//ErrorCodes
	public static final String GENERAL_ERROR_CODE = "ER_001";
	public static final String ORDER_SAVE="ER_002";
	public static final String ORDERS_NOT_FOUND="er_003";
	public static final String ORDER_SERVICE_MANAGMENT = "ER_004";
	
	
	
}
